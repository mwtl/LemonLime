window.addEventListener('lemonpi.content/ready', event => {
  const content = event.detail;
  //const source = event.detail.source

  //const message = {"adset-id":config.adsetId,
  //                 "creative-id":config.creativeId,
  //                 "ph-type":"content"};

  console.log(content);
})

var config;
console.log(config);
window.addEventListener('lemonpi.config/ready', event => {
  config = event.detail;
  console.log(config);

})
